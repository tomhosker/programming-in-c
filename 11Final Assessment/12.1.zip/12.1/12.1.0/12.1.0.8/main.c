#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "hoskersdl2.h"

#define ON 1
#define OFF 0

#define RED_AN 0x81
#define GREEN_AN 0x82
#define YELLOW_AN 0x83
#define BLUE_AN 0x84
#define MAGENTA_AN 0x85
#define CYAN_AN 0x86
#define WHITE_AN 0x87

void print_m7(unsigned char *m7file, SDL_Simplewin sw, fntrow fd[FNTCHARS][FNTHEIGHT]);

int toggle_graphics_mode(unsigned char c, int graphics_mode);

bool is_graphics_code(unsigned char c);

bool is_anfgc_code(unsigned char c);

bool is_anbgc_code(unsigned char c);

long decode_anfbc_code(unsigned char c);

void graphics_parser(unsigned char c, SDL_Simplewin sw, fntrow fd[FNTCHARS][FNTHEIGHT], int x, int y, long f, long b);

void char_parser(unsigned char c, SDL_Simplewin sw, fntrow fd[FNTCHARS][FNTHEIGHT], int x, int y, long f, long b);

bool is_ascii_code(unsigned char c);

bool is_non_ascii_code(unsigned char c);

unsigned char decode_ascii_code(unsigned char c);

unsigned char decode_non_ascii_code(unsigned char c);

int main(void)
{
  SDL_Simplewin sw;
  fntrow fd[FNTCHARS][FNTHEIGHT];
  char buffer[(CHARS_ACROSS*CHARS_DOWN)+1];
  FILE *file;

  Neill_SDL_ReadFont(fd, "m7fixed.fnt");

  file = fopen("test.m7", "r");
  if(file == NULL)
  {
    exit(-1);
  }
  if(strcmp(fgets(buffer, (CHARS_ACROSS*CHARS_DOWN)+1, file), buffer) != 0)
  {
    printf("Error reading file.\n");
    return(0);
  }

  Neill_SDL_Init(&sw);
  do{
     SDL_Delay(1);

     print_m7(buffer, sw, fd);

     Neill_SDL_UpdateScreen(&sw);

     /* Has anyone pressed ESC or killed the SDL window ?
        Must be called frequently - it's the only way of escaping  */
     Neill_SDL_Events(&sw);

  }while(!sw.finished);


  /* Clear up graphics subsystems */
  atexit(SDL_Quit);

  return 0;
}

void print_m7(unsigned char *m7file, SDL_Simplewin sw, fntrow fd[FNTCHARS][FNTHEIGHT])
{
  unsigned char c;
  long f = WHITE;
  long b = BLACK;
  int graphics_mode = OFF;
  int i;
  int x = 0;
  int y = 0;

  /* Walk through each character. */
  for(i = 0; i <= (CHARS_ACROSS*CHARS_DOWN); i++)
  {
    c = m7file[i];

    graphics_mode = toggle_graphics_mode(c, graphics_mode);

    /* Check for colour codes and take appropriate action. */
    if(is_anfgc_code(c) || is_anbgc_code(c))
    {
      if(is_anfgc_code(c))
      {
        f = decode_anfbc_code(c);
        Neill_SDL_DrawChar(&sw, fd, ' ', x, y, f, b);
      }
      else
      {
        if(c == 0x9C)
        {
          b = BLACK;
          Neill_SDL_DrawChar(&sw, fd, ' ', x, y, f, b);
        }
        else
        {
          b = f;
          Neill_SDL_DrawChar(&sw, fd, ' ', x, y, f, b);
        }
      }
    }

    /* Parse either graphics of text, as appropriate. */
    else if(graphics_mode == ON)
    {
      graphics_parser(c, sw, fd, x, y, f, b);
    }
    else
    {
      char_parser(c, sw, fd, x, y, f, b);
    }

    /* How to end a line. */
    if((i%CHARS_ACROSS) == (CHARS_ACROSS-1))
    {
      f = WHITE;
      b = BLACK;
      x = 0;
      y = y+FNTHEIGHT;
    }
    else
    {
      x = x+FNTWIDTH;
    }
  }
}

int toggle_graphics_mode(unsigned char c, int graphics_mode)
{
  if(is_graphics_code(c) == true)
  {
    return(ON);
  }
  else if(is_anfgc_code(c) == true)
  {
    return(OFF);
  }
  else if(is_anbgc_code(c) == true)
  {
    return(OFF);
  }
  else
  {
    return(graphics_mode);
  }
}

bool is_graphics_code(unsigned char c)
{
  if((c >= 0x90) && (c <= 0x9B))
  {
    return(true);
  }
  else if((c >= 0x9E) && (c <= 0x9F))
  {
    return(true);
  }
  else
  {
    return(false);
  }
}

bool is_anfgc_code(unsigned char c)
{
  return c >= 0x80 && c <= 0x88;
}

bool is_anbgc_code(unsigned char c)
{
  return c >= 0x9C && c <= 0x9D;
}

long decode_anfbc_code(unsigned char c)
{
  if(c == RED_AN)
  {
    return(RED);
  }
  else if(c == GREEN_AN)
  {
    return(GREEN);
  }
  else if(c == YELLOW_AN)
  {
    return(YELLOW);
  }
  else if(c == BLUE_AN)
  {
    return(BLUE);
  }
  else if(c == MAGENTA_AN)
  {
    return(MAGENTA);
  }
  else if(c == CYAN_AN)
  {
    return(CYAN);
  }
  else if(c == WHITE_AN)
  {
    return(WHITE);
  }
  else
  {
    return(WHITE);
  }
}

void graphics_parser(unsigned char c, SDL_Simplewin sw, fntrow fd[FNTCHARS][FNTHEIGHT], int x, int y, long f, long b)
{
  Neill_SDL_DrawChar(&sw, fd, '[', x, y, f, b);
}

void char_parser(unsigned char c, SDL_Simplewin sw, fntrow fd[FNTCHARS][FNTHEIGHT], int x, int y, long f, long b)
{
  if(is_ascii_code(c))
  {
    c = decode_ascii_code(c);
    Neill_SDL_DrawChar(&sw, fd, c, x, y, f, b);
  }
  else if(is_non_ascii_code(c))
  {
    c = decode_non_ascii_code(c);
    Neill_SDL_DrawChar(&sw, fd, c, x, y, f, b);
  }
  else
  {
    /* Unknown character; print a space. */
    Neill_SDL_DrawChar(&sw, fd, ' ', x, y, f, b);
  }
}

bool is_ascii_code(unsigned char c)
{
  if(c < 0x80)
  {
    return(true);
  }
  else if((c >= 0xA0) && (c <= 0xDA))
  {
    return(true);
  }
  else if((c >= 0xE1) && (c <= 0xFA))
  {
    return(true);
  }
  else
  {
    return(false);
  }
}

bool is_non_ascii_code(unsigned char c)
{
  if((c >= 0xDB) && (c <= 0xE0))
  {
    return(true);
  }
  else if(c >= 0xFB)
  {
    return(true);
  }
  else
  {
    return(false);
  }
}

unsigned char decode_ascii_code(unsigned char c)
{
  if(c >= 0x80)
  {
    return(c-0x80);
  }
  else
  {
    return(c);
  }
}

unsigned char decode_non_ascii_code(unsigned char c)
{
  return('~');
}
