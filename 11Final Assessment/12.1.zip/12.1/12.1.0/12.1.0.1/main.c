#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

#define LINE_WIDTH 40
#define LINE_HEIGHT 25
#define SMALLEST_CODE_NO 128

void print_m7(unsigned char *line);

bool printable(unsigned char c) {
  return c < 0x80 || (c >= 0xA0 && c <= 0xFF);
}

bool control(unsigned char c) {
  return c >= 0x80 && c <= 0x9F;
}

int main(int argc, char *argv[])
{
  char buffer[LINE_WIDTH*LINE_HEIGHT];
  if(argc != 2)
    exit(-1);

  FILE *file;
  file = fopen(argv[1], "r");
  printf("%s", argv[1]);
  if(file == NULL)
    exit(-1);

  fgets(buffer, LINE_WIDTH*LINE_HEIGHT, file);    
  print_m7(buffer);

  return(0);
}

void print_m7(unsigned char *line) {
  for(int i = 0; i <= LINE_WIDTH * LINE_HEIGHT; i++) {
    unsigned char c = line[i];

//    printf("%i,", c);

    if(control(c)) {
      if(c == 0x81)
        printf("\e[0;31;49m");

      putchar(' ');
    } else if(printable(c)) {
      if(c >= 0x80)
	putchar(c-0x80);
      else
        putchar(c);
    } else {
      // some unknown character, so just print a space...
      putchar(' ');
    }

    if(i % LINE_WIDTH == 0) {
      printf("\e[0;39;49m");
      putchar('\n');
      // should reset color and stuff here
    }
  }
}
