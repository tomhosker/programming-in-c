#include <stdio.h>
#include <stdlib.h>
#include "neillsdl2_dash.h"

#define RECTSIZE 20
#define MILLISECONDDELAY 20

int main(void)
{
   SDL_Simplewin sw;
   SDL_Rect rectangle;

   fntrow fd[FNTCHARS][FNTHEIGHT];
   int white[3] = {255,255,255};
   int black[3] = {0,0,0};
   int red[3] = {255,0,0};

   rectangle.w = RECTSIZE;
   rectangle.h = RECTSIZE;

   Neill_SDL_Init(&sw);
   do{
      SDL_Delay(MILLISECONDDELAY);

      Neill_SDL_ReadFont(fd, "m7fixed.fnt");
      Neill_SDL_DrawChar(&sw, fd, 'a', 100, 100, red, black);

      /* Choose a random colour, a mixture of red, green and blue. */
      Neill_SDL_SetDrawColour(&sw,
                             90, 120,
                             45);

      /* Filled Rectangle, fixed size */
      rectangle.x = 0;
      rectangle.y = 0;
      SDL_RenderFillRect(sw.renderer, &rectangle);

      /* Unfilled Rectangle, fixed size, random position */
      rectangle.x = rand()%(WWIDTH-RECTSIZE);
      rectangle.y = rand()%(WHEIGHT-RECTSIZE);
      SDL_RenderDrawRect(sw.renderer, &rectangle);

      Neill_SDL_UpdateScreen(&sw);

      /* Has anyone pressed ESC or killed the SDL window ?
         Must be called frequently - it's the only way of escaping  */
      Neill_SDL_Events(&sw);

   }while(!sw.finished);


   /* Clear up graphics subsystems */
   atexit(SDL_Quit);

   return 0;

}
