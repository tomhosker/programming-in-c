#include <stdio.h>
#include <stdlib.h>
#include "neillsdl2_dash.h"

#define RECTSIZE 20
#define MILLISECONDDELAY 20

int main(void)
{
   SDL_Simplewin sw;
   SDL_Rect rectangle;

   fntrow fd[FNTCHARS][FNTHEIGHT];

   rectangle.w = RECTSIZE;
   rectangle.h = RECTSIZE;

   Neill_SDL_Init(&sw);
   do{
      SDL_Delay(MILLISECONDDELAY);

      Neill_SDL_ReadFont(fd, "m7fixed.fnt");
      Neill_SDL_DrawChar(&sw, fd, 'a', 100, 100, RED, BLACK);

      /* Chooses a colour. */
      Hosker_SDL_SetDrawColour(&sw, BLUE);

      /* Filled Rectangle, fixed size */
      rectangle.x = 0;
      rectangle.y = 0;
      SDL_RenderFillRect(sw.renderer, &rectangle);

      /* Unfilled Rectangle, fixed size, random position */
      rectangle.x = rand()%(WWIDTH-RECTSIZE);
      rectangle.y = rand()%(WHEIGHT-RECTSIZE);
      SDL_RenderDrawRect(sw.renderer, &rectangle);

      Neill_SDL_UpdateScreen(&sw);

      /* Has anyone pressed ESC or killed the SDL window ?
         Must be called frequently - it's the only way of escaping  */
      Neill_SDL_Events(&sw);

   }while(!sw.finished);


   /* Clear up graphics subsystems */
   atexit(SDL_Quit);

   return 0;
}
