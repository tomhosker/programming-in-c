#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

#define LINE_WIDTH 40
#define LINES 25
#define SMALLEST_CODE_NO 128
#define BLACK 0x80
#define WHITE 0x87
#define ON 1
#define OFF 0

void print_m7(unsigned char *m7file);

void graphics_parser(unsigned char c);

void char_parser(unsigned char c);

bool is_anfgc_code(unsigned char c); /* I.e. Is it an Alpha-Numeric ForeGround Colour code? */

bool is_anbgc_code(unsigned char c); /* I.e. Is it an Alpha-Numeric BackGround Colour code? */

bool is_ascii_code(unsigned char c);

bool is_non_ascii_code(unsigned char c); /* I.e. Is it a non-ASCII character? */

bool is_graphics_code(unsigned char c);

void decode_anfbc_code(unsigned char f, unsigned char b); /* I.e. Decode Alpha-Numeric Foreground-Background Colour code. */

void decode_ascii_code(unsigned char c);

void decode_non_ascii_code(unsigned char c);

int toggle_graphics_mode(unsigned char c, int graphics_mode);

int main(int argc, char *argv[])
{
  char buffer[LINE_WIDTH*LINES];
  if(argc != 2)
  {
    exit(-1);
  }

  FILE *file;
  file = fopen(argv[1], "r");
  if(file == NULL)
  {
    exit(-1);
  }

  fgets(buffer, LINE_WIDTH*LINES, file);
  print_m7(buffer);

  return(0);
}

void print_m7(unsigned char *m7file)
{
  unsigned char c;
  unsigned char f = WHITE;
  unsigned char b = BLACK;
  int graphics_mode = OFF;

  /* Initialise background and text colours. */ 
  decode_anfbc_code(f, b); putchar('\n');

  /* Walk through each character. */
  for(int i = 0; i <= (LINE_WIDTH*LINES); i++)
  {
    c = m7file[i];

    graphics_mode = toggle_graphics_mode(c, graphics_mode);

    /* Check for colour codes and take appropriate action. */
    if(is_anfgc_code(c) || is_anbgc_code(c))
    {
      if(is_anfgc_code(c))
      {
        f = c;
        decode_anfbc_code(f, b);
      }
      else
      {
        if(c == 0x9C)
        {
          b = BLACK;
          decode_anfbc_code(f, b);
        }
        else
        {
          b = f;
          decode_anfbc_code(f, b);
        }
      }
    }

    /* Parse either graphics of text, as appropriate. */
    else if(graphics_mode == ON)
    {
      graphics_parser(c);
    }
    else
    {
      char_parser(c);
    }

    /* How to end a line. */
    if((i%LINE_WIDTH) == (LINE_WIDTH-1))
    {
      f = WHITE;
      b = BLACK;
      decode_anfbc_code(f, b); putchar('\n');
    }
  }

  printf("\e[0;39;49m");
  printf("\n");
}

void graphics_parser(unsigned char c)
{
  putchar('[');
}

void char_parser(unsigned char c)
{
  if(is_ascii_code(c))
  {
    decode_ascii_code(c);
  }
  else if(is_non_ascii_code(c))
  {
    decode_non_ascii_code(c);
  }
  else
  {
    /* Unknown character; print a space. */
    putchar(' ');
  }
}

bool is_anfgc_code(unsigned char c)
{
  return c >= 0x80 && c <= 0x8F;
}

bool is_anbgc_code(unsigned char c)
{
  return c >= 0x9C && c <= 0x9D;
}

bool is_ascii_code(unsigned char c)
{
  if(c < 0x80)
  {
    return(true);
  }
  else if((c >= 0xA0) && (c <= 0xDA))
  {
    return(true);
  }
  else if((c >= 0xE1) && (c <= 0xFA))
  {
    return(true);
  }
  else
  {
    return(false);
  }
}

bool is_non_ascii_code(unsigned char c)
{
  if((c >= 0xDB) && (c <= 0xE0))
  {
    return(true);
  }
  else if((c >= 0xFB) && (c <= 0xFF))
  {
    return(true);
  }
  else
  {
    return(false);
  }
}

bool is_graphics_code(unsigned char c)
{
  if((c >= 0x90) && (c <= 0x9B))
  {
    return(true);
  }
  else if((c >= 0x9E) && (c <= 0x9F))
  {
    return(true);
  }
  else
  {
    return(false);
  }
}

void decode_anfbc_code(unsigned char f, unsigned char b)
{
  unsigned char f_dash = f-0x80;
  unsigned char b_dash = b-0x80;

  printf("\e[0;3%i;4%im", f_dash, b_dash);
  putchar(' ');
}

void decode_ascii_code(unsigned char c)
{
  if(c >= 0x80)
  {
    putchar(c-0x80);
  }
  else
  {
    putchar(c);
  }
}

void decode_non_ascii_code(unsigned char c)
{
  if(c == 0xE0)
  {
    putchar('-');
  }
  else
  {
    putchar('~');
  }
}

int toggle_graphics_mode(unsigned char c, int graphics_mode)
{
  if(is_graphics_code(c) == true)
  {
    return(ON);
  }
  else if(is_anfgc_code(c) == true)
  {
    if(graphics_mode == ON)
    {
      printf("\b]");
    }
    return(OFF);
  }
  else if(is_anbgc_code(c) == true)
  {
    if(graphics_mode == ON)
    {
      printf("\b]");
    }
    return(OFF);
  }
  else
  {
    return(graphics_mode);
  }
}
