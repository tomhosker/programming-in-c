#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "hoskersdl2.h"
#include "controlcodes.h"

#define NORMAL_FONT_FILE "m7fixed.fnt"
#define CONTIGUOUS_GRAPHICS_FONT_FILE "sixels_c.fnt"
#define SEPARATED_GRAPHICS_FONT_FILE "sixels_s.fnt"

#define OFF 0
#define ON 1

#define CONTIGUOUS 1
#define SEPARATED 2

#define UPPER 1
#define LOWER 2

void print_m7(unsigned char *m7file, SDL_Simplewin sw, fntrow fd[FNTCHARS][FNTHEIGHT], fntrow sixels_c[FNTCHARS][FNTHEIGHT], fntrow sixels_s[FNTCHARS][FNTHEIGHT]);

int toggle_graphics_mode(unsigned char c, int graphics_mode);

int toggle_dh_mode(unsigned char c, unsigned char c_above, unsigned char c_next, unsigned char c_above_next, int dh_mode);

int toggle_hold_graphics(unsigned char c, int hold_graphics);

bool is_graphics_code(unsigned char c);

bool is_graphics_colour_code(unsigned char c);

bool is_anfgc_code(unsigned char c);

bool is_anbgc_code(unsigned char c);

long decode_anfbc_code(unsigned char c);

long decode_graphics_colour_code(unsigned char c);

void graphics_parser(unsigned char c, SDL_Simplewin sw, fntrow sixels_c[FNTCHARS][FNTHEIGHT], fntrow sixels_s[FNTCHARS][FNTHEIGHT], int x, int y, long f, long b, int graphics_mode);

void dh_parser(unsigned char c, SDL_Simplewin sw, fntrow fd[FNTCHARS][FNTHEIGHT], int x, int y, long f, long b, int dh_mode);

void char_parser(unsigned char c, SDL_Simplewin sw, fntrow fd[FNTCHARS][FNTHEIGHT], int x, int y, long f, long b);

bool is_ascii_code(unsigned char c);

bool is_non_ascii_code(unsigned char c);

unsigned char decode_ascii_code(unsigned char c);

unsigned char decode_non_ascii_code(unsigned char c);

int main(int argc, char *argv[])
{
  SDL_Simplewin sw;
  fntrow fd[FNTCHARS][FNTHEIGHT];
  fntrow sixels_c[FNTCHARS][FNTHEIGHT];
  fntrow sixels_s[FNTCHARS][FNTHEIGHT];
  char buffer[(CHARS_ACROSS*CHARS_DOWN)+1];
  FILE *file;

  if(argc != 2)
  {
    exit(-1);
  }

  Neill_SDL_ReadFont(fd, NORMAL_FONT_FILE);
  Neill_SDL_ReadFont(sixels_c, CONTIGUOUS_GRAPHICS_FONT_FILE);
  Neill_SDL_ReadFont(sixels_s, SEPARATED_GRAPHICS_FONT_FILE);

  file = fopen(argv[1], "r");
  if(file == NULL)
  {
    exit(-1);
  }
  if(strcmp(fgets(buffer, (CHARS_ACROSS*CHARS_DOWN)+1, file), buffer) != 0)
  {
    printf("Error reading file.\n");
    return(0);
  }

  /* Neill's code for making an SDL window, adapted. */
  Neill_SDL_Init(&sw);
  do{
     SDL_Delay(1);
     print_m7((unsigned char *)buffer, sw, fd, sixels_c, sixels_s);
     Neill_SDL_UpdateScreen(&sw);
     Neill_SDL_Events(&sw);
  }while(!sw.finished);
  atexit(SDL_Quit);

  return(0);
}

void print_m7(unsigned char *m7file, SDL_Simplewin sw, fntrow fd[FNTCHARS][FNTHEIGHT], fntrow sixels_c[FNTCHARS][FNTHEIGHT], fntrow sixels_s[FNTCHARS][FNTHEIGHT])
{
  unsigned char c;
  unsigned char c_above = 0x00;
  unsigned char c_next = 0x00;
  unsigned char c_above_next = 0x00;
  long f = WHITE;
  long b = BLACK;
  int graphics_mode = OFF;
  int dh_mode = OFF;
  int hold_graphics = OFF;
  int i;
  int x = 0;
  int y = 0;

  /* Walk through each character. */
  for(i = 0; i <= (CHARS_ACROSS*CHARS_DOWN); i++)
  {
    c = m7file[i];

    if(i >= CHARS_ACROSS)
    {
      c_above = m7file[i-CHARS_ACROSS];
    }
    if(i != (CHARS_ACROSS*CHARS_DOWN))
    {
      c_next = m7file[i+1];
    }
    if(i >= CHARS_ACROSS)
    {
      c_above_next = m7file[i-CHARS_ACROSS+1];
    }

    graphics_mode = toggle_graphics_mode(c, graphics_mode);
    hold_graphics = toggle_hold_graphics(c, hold_graphics);

    /* Check for colour codes and take appropriate action. */
    if(is_anfgc_code(c) || is_anbgc_code(c))
    {
      if(is_anfgc_code(c))
      {
        f = decode_anfbc_code(c);
        Neill_SDL_DrawChar(&sw, fd, ' ', x, y, f, b);
      }
      else
      {
        if(c == BLACK_BG)
        {
          b = BLACK;
          Neill_SDL_DrawChar(&sw, fd, ' ', x, y, f, b);
        }
        else
        {
          b = f;
          Neill_SDL_DrawChar(&sw, fd, ' ', x, y, f, b);
        }
      }
    }

    /* Parse either graphics of text, as appropriate. */
    else if(graphics_mode != OFF)
    {
      if(c >= FIRST_ASCII_A)
      {
        graphics_parser(c, sw, sixels_c, sixels_s, x, y, f, b, graphics_mode);
      }
      else if(is_graphics_colour_code(c))
      {
        f = decode_graphics_colour_code(c);
        if(hold_graphics == OFF)
        {
          Neill_SDL_DrawChar(&sw, fd, ' ', x, y, f, b);
        }
        else
        {
          Neill_SDL_DrawChar(&sw, fd, ' ', x, y, f, f);
        }
      }
      else if(is_anbgc_code(c))
      {
        if(c == BLACK_BG)
        {
          b = BLACK;
          Neill_SDL_DrawChar(&sw, fd, ' ', x, y, f, b);
        }
        else
        {
          b = f;
          Neill_SDL_DrawChar(&sw, fd, ' ', x, y, f, b);
        }
      }
      else if(c == HOLD_GR)
      {
        Neill_SDL_DrawChar(&sw, fd, ' ', x, y, f, f);
      }
      else
      {
        Neill_SDL_DrawChar(&sw, fd, ' ', x, y, f, b);
      }
    }
    else if(dh_mode != OFF)
    {
      dh_parser(c, sw, fd, x, y, f, b, dh_mode);
    }
    else
    {
      char_parser(c, sw, fd, x, y, f, b);
    }

    /* How to end a line. */
    if((i%CHARS_ACROSS) == (CHARS_ACROSS-1))
    {
      f = WHITE;
      b = BLACK;
      x = 0;
      y = y+FNTHEIGHT;
      dh_mode = OFF;
      graphics_mode = OFF;
    }
    else
    {
      dh_mode = toggle_dh_mode(c, c_above, c_next, c_above_next, dh_mode);
      x = x+FNTWIDTH;
    }
  }
}

int toggle_graphics_mode(unsigned char c, int graphics_mode)
{
  if(is_graphics_code(c) == true)
  {
    if(c == SEPARATED_GR)
    {
      return(SEPARATED);
    }
    else
    {
      return(CONTIGUOUS);
    }
  }
  else if(is_anfgc_code(c) == true)
  {
    return(OFF);
  }
  else if(is_anbgc_code(c) == true)
  {
    return(OFF);
  }
  else
  {
    return(graphics_mode);
  }
}

int toggle_dh_mode(unsigned char c, unsigned char c_above, unsigned char c_next, unsigned char c_above_next, int dh_mode)
{
  if(c == SINGLE_HEIGHT)
  {
    return(OFF);
  }
  else if(c == DOUBLE_HEIGHT)
  {
    if(c_above == DOUBLE_HEIGHT)
    {
      return(LOWER);
    }
    else
    {
      return(UPPER);
    }
  }
  else if((c == SPACE) && (c_above == DOUBLE_HEIGHT) && (c_next == c_above_next))
  {
    return(LOWER);
  }
  else
  {
    return(dh_mode);
  }
}

int toggle_hold_graphics(unsigned char c, int hold_graphics)
{
  if(c == HOLD_GR)
  {
    return(ON);
  }
  else if(c == RELEASE_GR)
  {
    return(OFF);
  }
  else
  {
    return(hold_graphics);
  }
}

bool is_graphics_code(unsigned char c)
{
  if((c >= FIRST_GR) && (c <= LAST_GR))
  {
    return(true);
  }
  else if((c == HOLD_GR) || (c == RELEASE_GR))
  {
    return(true);
  }
  else
  {
    return(false);
  }
}

bool is_graphics_colour_code(unsigned char c)
{
  if((c >= FIRST_GR_CC) && (c <= LAST_GR_CC))
  {
    return(true);
  }
  else
  {
    return(false);
  }
}

bool is_anfgc_code(unsigned char c)
{
  if((c >= FIRST_ANFGC) && (c <= LAST_ANFGC))
  {
    return(true);
  }
  else
  {
    return(false);
  }
}

bool is_anbgc_code(unsigned char c)
{
  if((c == BLACK_BG) || (c == NEW_BG))
  {
    return(true);
  }
  else
  {
    return(false);
  }
}

long decode_anfbc_code(unsigned char c)
{
  if(c == RED_AN)
  {
    return(RED);
  }
  else if(c == GREEN_AN)
  {
    return(GREEN);
  }
  else if(c == YELLOW_AN)
  {
    return(YELLOW);
  }
  else if(c == BLUE_AN)
  {
    return(BLUE);
  }
  else if(c == MAGENTA_AN)
  {
    return(MAGENTA);
  }
  else if(c == CYAN_AN)
  {
    return(CYAN);
  }
  else if(c == WHITE_AN)
  {
    return(WHITE);
  }
  else
  {
    return(WHITE);
  }
}

long decode_graphics_colour_code(unsigned char c)
{
  if(c == RED_GR)
  {
    return(RED);
  }
  else if(c == GREEN_GR)
  {
    return(GREEN);
  }
  else if(c == YELLOW_GR)
  {
    return(YELLOW);
  }
  else if(c == BLUE_GR)
  {
    return(BLUE);
  }
  else if(c == MAGENTA_GR)
  {
    return(MAGENTA);
  }
  else if(c == CYAN_GR)
  {
    return(CYAN);
  }
  else if(c == WHITE_GR)
  {
    return(WHITE);
  }
  else
  {
    return(WHITE);
  }
}

void graphics_parser(unsigned char c, SDL_Simplewin sw, fntrow sixels_c[FNTCHARS][FNTHEIGHT], fntrow sixels_s[FNTCHARS][FNTHEIGHT], int x, int y, long f, long b, int graphics_mode)
{
  c = c-FIRST_CONTROL;
  if(graphics_mode == CONTIGUOUS)
  {
    Neill_SDL_DrawChar(&sw, sixels_c, c, x, y, f, b);
  }
  else
  {
    Neill_SDL_DrawChar(&sw, sixels_s, c, x, y, f, b);
  }
}

void dh_parser(unsigned char c, SDL_Simplewin sw, fntrow fd[FNTCHARS][FNTHEIGHT], int x, int y, long f, long b, int dh_mode)
{
  unsigned char c_dash;

  if(is_ascii_code(c) == true)
  {
    c_dash = decode_ascii_code(c);
    if(dh_mode == LOWER)
    {
      draw_lower_dh(&sw, fd, c_dash, x, y, f, b);
    }
    else
    {
      draw_upper_dh(&sw, fd, c_dash, x, y, f, b);
    }
  }
  else
  {
    Neill_SDL_DrawChar(&sw, fd, ' ', x, y, f, b);
  }
}

void char_parser(unsigned char c, SDL_Simplewin sw, fntrow fd[FNTCHARS][FNTHEIGHT], int x, int y, long f, long b)
{
  if(is_ascii_code(c))
  {
    c = decode_ascii_code(c);
    Neill_SDL_DrawChar(&sw, fd, c, x, y, f, b);
  }
  else if(is_non_ascii_code(c))
  {
    c = decode_non_ascii_code(c);
    Neill_SDL_DrawChar(&sw, fd, c, x, y, f, b);
  }
  else
  {
    /* Unknown character; print a space. */
    Neill_SDL_DrawChar(&sw, fd, ' ', x, y, f, b);
  }
}

bool is_ascii_code(unsigned char c)
{
  if(c < FIRST_CONTROL)
  {
    return(true);
  }
  else if((c >= FIRST_ASCII_A) && (c <= LAST_ASCII_A))
  {
    return(true);
  }
  else if((c >= FIRST_ASCII_B) && (c <= LAST_ASCII_B))
  {
    return(true);
  }
  else
  {
    return(false);
  }
}

bool is_non_ascii_code(unsigned char c)
{
  if((c >= FIRST_NON_ASCII_A) && (c <= LAST_NON_ASCII_A))
  {
    return(true);
  }
  else if(c >= FIRST_NON_ASCII_B)
  {
    return(true);
  }
  else
  {
    return(false);
  }
}

unsigned char decode_ascii_code(unsigned char c)
{
  if(c >= FIRST_CONTROL)
  {
    return(c-FIRST_CONTROL);
  }
  else
  {
    return(c);
  }
}

unsigned char decode_non_ascii_code(unsigned char c)
{
  return(c-FIRST_CONTROL);
}
