#define REDAN_STR "81"
#define GREENAN_STR "82"
#define YELLOWAN_STR "83"
#define BLUEAN_STR "84"
#define MAGENTAAN_STR "85"
#define CYANAN_STR "86"
#define WHITEAN_STR "87"

#define SINGLEHT_STR "8c"
#define DOUBLEHT_STR "8d"

#define REDGR_STR "91"
#define GREENGR_STR "92"
#define YELLOWGR_STR "93"
#define BLUEGR_STR "94"
#define MAGENTAGR_STR "95"
#define CYANGR_STR "96"
#define WHITEGR_STR "97"

#define CONTIGR_STR "99"
#define SEPARGR_STR "9a"

#define BLKBACK_STR "9c"
#define NEWBACK_STR "9d"

#define HOLDGR_STR "9e"
#define RELSGR_STR "9f"

#define SPACE_STR "a0"
