#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "controlstrings.h"

#define CHARS_ACROSS 40
#define CHARS_DOWN 25
#define GRID_SIZE CHARS_ACROSS*CHARS_DOWN
#define BUFFER_SIZE CHARS_ACROSS*CHARS_DOWN*10

void translate(unsigned char *assembly, char *machine);

void command_parser(unsigned char *token, FILE *file, int count);

void weirdness_parser(unsigned char *token, FILE *file);

int main(int argc, char *argv[])
{
  unsigned char buffer[BUFFER_SIZE];
  unsigned char buffer_dash[BUFFER_SIZE];
  unsigned char *buffer_ddash;
  FILE *file;

  buffer[0] = '\0';
  buffer_dash[0] = '\0';

  if(argc != 2)
  {
    exit(-1);
  }

  file = fopen(argv[1], "r");
  if(file == NULL)
  {
    exit(-1);
  }
  while(fgets((char*)buffer_dash, BUFFER_SIZE, file) != NULL)
  {
    buffer_ddash = (unsigned char*)strtok((char*)buffer_dash, "\n");
    strcat((char*)buffer, (char*)buffer_ddash);
  }

  translate(buffer, "translated.txt");

  return(0);
}

void translate(unsigned char *assembly, char *machine)
{
  FILE *file;
  int count = 0;
  unsigned char *token;
  const char s[2] = " ";

  file = fopen(machine, "w");
  if(file == NULL)
  {
    exit(-1);
  }

  token = (unsigned char*)strtok((char*)assembly, s);
  
  while(token != NULL)
  {
    if(count%16 == 0)
    {
      fprintf(file, "%08x: ", count);
    }

    if(strlen((char*)token) == 1)
    {
      token[0] = token[0]+0x80;
      fprintf(file, "%x ", (int)token[0]);
    }
    else if(strcmp((char*)token, "NEWLINE") == 0)
    {
      command_parser(token, file, count);
      count = count-(count%CHARS_ACROSS)+CHARS_ACROSS-1;
    }
    else
    {
      command_parser(token, file, count);
    }

    if(count%16 == 15)
    {
      fprintf(file, "\n");
    }

    token = (unsigned char*)strtok(NULL, s);
    count++;
  }
}

void command_parser(unsigned char *token, FILE *file, int count)
{
  if(strcmp((char*)token, "SPACE") == 0)
  {
    fprintf(file, "%s ", SPACE_STR);
  }
  else if(strcmp((char*)token, "NEWLINE") == 0)
  {
    while(count%CHARS_ACROSS != 0)
    {
      if(count%16 == 0)
      {
        fprintf(file, "\n%08x: ", count);
      }
      fprintf(file, "%s ", "a0");
      count++;
    }
  }
  else if(strcmp((char*)token, "END") == 0)
  {
    while(GRID_SIZE-count > 0)
    {
      if(count%16 == 0)
      {
        fprintf(file, "\n%08x: ", count);
      }
      fprintf(file, "%s ", "a0");
      count++;
    }
  }
  else
  {
    weirdness_parser(token, file);
  }
}

void weirdness_parser(unsigned char *token, FILE *file)
{
  if(strcmp((char*)token, "REDAN") == 0)
  {
    fprintf(file, "%s ", REDAN_STR);
  }
  else if(strcmp((char*)token, "GREENAN") == 0)
  {
    fprintf(file, "%s ", GREENAN_STR);
  }
  else if(strcmp((char*)token, "YELLOWAN") == 0)
  {
    fprintf(file, "%s ", YELLOWAN_STR);
  }
  else if(strcmp((char*)token, "BLUEAN") == 0)
  {
    fprintf(file, "%s ", BLUEAN_STR);
  }
  else if(strcmp((char*)token, "MAGENTAAN") == 0)
  {
    fprintf(file, "%s ", MAGENTAAN_STR);
  }
  else if(strcmp((char*)token, "CYANAN") == 0)
  {
    fprintf(file, "%s ", CYANAN_STR);
  }
  else if(strcmp((char*)token, "WHITEAN") == 0)
  {
    fprintf(file, "%s ", WHITEAN_STR);
  }
  else if(strcmp((char*)token, "SINGLEHT") == 0)
  {
    fprintf(file, "%s ", SINGLEHT_STR);
  }
  else if(strcmp((char*)token, "DOUBLEHT") == 0)
  {
    fprintf(file, "%s ", DOUBLEHT_STR);
  }
  else if(strcmp((char*)token, "REDGR") == 0)
  {
    fprintf(file, "%s ", REDGR_STR);
  }
  else if(strcmp((char*)token, "GREENGR") == 0)
  {
    fprintf(file, "%s ", GREENGR_STR);
  }
  else if(strcmp((char*)token, "YELLOWGR") == 0)
  {
    fprintf(file, "%s ", YELLOWGR_STR);
  }
  else if(strcmp((char*)token, "BLUEGR") == 0)
  {
    fprintf(file, "%s ", BLUEGR_STR);
  }
  else if(strcmp((char*)token, "MAGENTAGR") == 0)
  {
    fprintf(file, "%s ", MAGENTAGR_STR);
  }
  else if(strcmp((char*)token, "CYANGR") == 0)
  {
    fprintf(file, "%s ", CYANGR_STR);
  }
  else if(strcmp((char*)token, "WHITEGR") == 0)
  {
    fprintf(file, "%s ", WHITEGR_STR);
  }
  else if(strcmp((char*)token, "CONTIGR") == 0)
  {
    fprintf(file, "%s ", CONTIGR_STR);
  }
  else if(strcmp((char*)token, "SEPARGR") == 0)
  {
    fprintf(file, "%s ", SEPARGR_STR);
  }
  else if(strcmp((char*)token, "BLKBACK") == 0)
  {
    fprintf(file, "%s ", BLKBACK_STR);
  }
  else if(strcmp((char*)token, "NEWBACK") == 0)
  {
    fprintf(file, "%s ", NEWBACK_STR);
  }
  else if(strcmp((char*)token, "HOLDGR") == 0)
  {
    fprintf(file, "%s ", HOLDGR_STR);
  }
  else if(strcmp((char*)token, "RELSGR") == 0)
  {
    fprintf(file, "%s ", RELSGR_STR);
  }
}
