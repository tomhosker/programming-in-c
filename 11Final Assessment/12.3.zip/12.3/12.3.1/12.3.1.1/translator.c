#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define CHARS_ACROSS 40
#define CHARS_DOWN 25
#define GRID_SIZE CHARS_ACROSS*CHARS_DOWN
#define BUFFER_SIZE CHARS_ACROSS*CHARS_DOWN*10

void translate(char *assembly, char *machine);

void command_parser(char *token, FILE *file, int count);

int main(int argc, char *argv[])
{
  char buffer[BUFFER_SIZE];
  FILE *file;

  if(argc != 2)
  {
    exit(-1);
  }

  file = fopen(argv[1], "r");
  if(file == NULL)
  {
    exit(-1);
  }
  if(strcmp(fgets(buffer, BUFFER_SIZE, file),
     buffer) != 0)
  {
    printf("Error reading file.\n");
    return(0);
  }

  translate(buffer, "translated.txt");

  printf("Herro!\n");
  return(0);
}

void translate(char *assembly, char *machine)
{
  FILE *file;
  int count = 0;
  int count_dash;
  unsigned char *token;
  const char s[2] = " ";

  file = fopen(machine, "w");
  if(file == NULL)
  {
    exit(-1);
  }

  token = strtok(assembly, s);
  
  while(token != NULL)
  {
    if(count%16 == 0)
    {
      fprintf(file, "%08x: ", count);
    }

    if(strlen(token) == 1)
    {
      token[0] = token[0]+0x80;
      fprintf(file, "%x ", (int)token[0]);
    }
    else
    {
      command_parser(token, file, count);
    }

    if(count%16 == 15)
    {
      fprintf(file, "\n");
    }

    token = strtok(NULL, s);
    count++;
  }
}

void command_parser(char *token, FILE *file, int count)
{
  if(strcmp(token, "SPACE") == 0)
  {
    fprintf(file, "%s ", "a0");
  }
  else if(strcmp(token, "END") == 0)
  {
    while(GRID_SIZE-count > 0)
    {
      if(count%16 == 0)
      {
        fprintf(file, "%08x: ", count);
      }
      fprintf(file, "%s ", "a0");
      if(count%16 == 15)
      {
        fprintf(file, "\n");
      }
      count++;
    }
  }
}
