/*##########################################################
############################################################
###################### A Program in C ######################
####################### to Allow for #######################
################### the Creation and Use ###################
##################### of Logical Sets ######################
########################## v 1.2 ###########################
############################################################
###################### by TOM HOSKER #######################
############################################################
####################### 20 Nov 2017 ########################
############################################################
############# nisi Dominus aedificaverit domum #############
############################################################
############################################################
############### Znl gur fbhy bs Qnivq Pbbx, ################
################### Puvrs Bssvpre Eblny ####################
################# Syrrg Nhkvyvnel Freivpr, #################
##################### jevgur va ntbal ######################
################## orgjrra Fngna'f grrgu. ##################
############################################################
##########################################################*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "set.h"

#define NOT_AN_ELEMENT 0

/* Create empty set */
set* set_init()
{
  set* l;

  l = calloc(1, sizeof(set));
  if(l == NULL)
  {
    ON_ERROR("Creation of set failed.\n");
  }

  l->ua = arr_init();
  l->sz = 0;

  return l;
}

/* Create new set, copied from another */
set* set_copy(set* s)
{
  set* l;
  int i, n;
  
  n = s->sz;

  l = set_init();

  for(i = 0; i < n; i++)
  {
    arr_set(l->ua, i, arr_get(s->ua, i));
  }
  l->sz = n;

  return(l);
}

/* MY FUNCTION */
/* This checks for duplicates of a *lower* index. */
/* A sub-function of set_fromarray. */
int previous_duplicates(arrtype* array, int i)
{
  int j;

  for(j = 1; i-j >= 0; j++)
  {
    if(array[i-j] == array[i])
    {
      return(1);
    }
  }
  return(0);
}

/* Create new set, copied from an array of length n */
set* set_fromarray(arrtype* a, int n)
{
  set* l;
  int i;
  int count = 0;

  l = set_init();

  if(a == NULL)
  {
    return(l);
  }
  
  for(i = 0; i < n; i++)
  {
    if(previous_duplicates(a, i) == 0)
    {
      arr_set(l->ua, count, a[i]);
      count++;
    }
  }
  l->sz = count;

  return(l);
}

/*####################
###Basic Operations###
####################*/

/* Add one element into the set */
void set_insert(set* s, arrtype l)
{
  arr* k;
  int n, i;

  if(s == NULL)
  {
    s = set_init();
  }
  
  k = s->ua;
  n = s->sz;

  for(i = 0; i < n; i++)
  {
    if(arr_get(k, i) == l)
    {
      return;
    }
  }

  arr_set(k, n, l);
  s->sz = n+1;
}

/* Return size of the set */
int set_size(set* s)
{
  if(s == NULL)
  {
    s = set_init();
  }

  return(s->sz);
}

/* Returns true if l is in the array, false elsewise */
int set_contains(set* s, arrtype l)
{
  int i, n;

  if(s == NULL)
  {
    s = set_init();
  }

  n = s->sz;

  for(i = 0; i < n; i++)
  {
    if(arr_get(s->ua, i) == l)
    {
      return(1);
    }
  }
  return(0);
}

/* MY FUNCTION */
/* This returns the index of l in s. */
/* A sub-function of set_remove. */
int set_find_index(set* s, arrtype l)
{
  int i, n;

  if(s == NULL)
  {
    return(-1);
  }

  n = s->sz;

  if(set_contains(s, l) == 0)
  {
    return(-1);
  }
  
  for(i = 0; i < n; i++)
  {
    if(arr_get(s->ua, i) == l)
    {
      return(i);
    }
  }

  return(-1);
}

/* Remove l from the set (if it's in) */
void set_remove(set* s, arrtype l)
{
  int i, index_of_l, n;

  if(s == NULL)
  {
    return;
  }

  n = s->sz;

  if(set_contains(s, l) == 0)
  {
    return;
  }
  
  index_of_l = set_find_index(s, l);

  for(i = index_of_l; i < n-1; i++)
  {
    arr_set(s->ua, i, arr_get(s->ua, i+1));
  }
  arr_set(s->ua, n-1, NOT_AN_ELEMENT);

  s->sz = n-1;
}

/* Remove one element from the set - there's no
   particular order for the elements, so any will do */
arrtype set_removeone(set* s)
{
  int i, n;

  if(s == NULL)
  {
    s = set_init();
  }

  n = s->sz;

  for(i = 0; i < n-1; i++)
  {
    arr_set(s->ua, i, arr_get(s->ua, i+1));
  }
  arr_set(s->ua, n-1, NOT_AN_ELEMENT);

  s->sz = n-1;

  return(arr_get(s->ua, 0));
}

/*########################
###Operations on 2 sets###
########################*/

/* Create a new set, containing all elements from s1 & s2 */
set* set_union(set* s1, set* s2)
{
  int i, n;
  int count = 0;
  set* new_set;

  if(s1 == NULL)
  {
    s1 = set_init();
  }
  if(s2 == NULL)
  {
    s2 = set_init();
  }

  new_set = set_init();
  new_set = set_copy(s1);

  n = s2->sz;
  
  for(i = 0; i < n; i++)
  {
    if(set_contains(s1, arr_get(s2->ua, i)) == 0)
    {
      set_insert(new_set, arr_get(s2->ua, i));
      count++;
    }
  }

  new_set->sz = (s1->sz)+count;

  return(new_set);
}

/* Create a new set, containing all elements in both s1 & s2 */
set* set_intersection(set* s1, set* s2)
{
  int i, n;
  int count = 0;
  set* new_set;

  if(s1 == NULL)
  {
    s1 = set_init();
  }
  if(s2 == NULL)
  {
    s2 = set_init();
  }

  new_set = set_init();

  n = s2->sz;

  for(i = 0; i < n; i++)
  {
    if(set_contains(s1, arr_get(s2->ua, i)) == 1)
    {
      set_insert(new_set, arr_get(s2->ua, i));
      count++;
    }
  }

  new_set->sz = count;

  return(new_set);
}

/*#############
###Finish up###
#############*/

/* Clears all space used, and sets pointer to NULL */
void set_free(set** s)
{
  set* s_dash;
  arr* a;

  if(s == NULL)
  {
    return;
  }

  s_dash = *s;
  a = s_dash->ua;
  arr_free(&a);

  s_dash->sz = 0;

  *s = NULL;
}
