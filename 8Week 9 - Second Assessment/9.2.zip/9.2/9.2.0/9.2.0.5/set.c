#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "set.h"

#define NOT_AN_ELEMENT 0

/* Create empty set */
set* set_init()
{
  set* l;

  l = calloc(1, sizeof(set));
  if(l == NULL)
  {
    ON_ERROR("Creation of set failed.\n");
  }

  l->ua = arr_init();
  l->sz = 0;

  return l;
}

/* Create new set, copied from another */
set* set_copy(set* s)
{
  set* l;
  int i, n;
  
  n = s->sz;

  l = calloc(1, sizeof(set));
  if(l == NULL)
  {
    ON_ERROR("Creation of set failed.\n");
  }

  l->ua = arr_init();
  for(i = 0; i < n; i++)
  {
    l->ua->data[i] = s->ua->data[i];
  }
  l->sz = n;

  return(l);
}

/* Create new set, copied from an array of length n */
set* set_fromarray(arrtype* a, int n)
{
  set* l;
  int i;

  l = calloc(1, sizeof(set));
  if(l == NULL)
  {
    ON_ERROR("Creation of set failed.\n");
  }

  l->ua = calloc(n, sizeof(arrtype));
  if(l->ua == NULL)
  {
    ON_ERROR("Creation of set failed.\n");
  }
  for(i = 0; i < n; i++)
  {
    l->ua->data[i] = a[i];
  }
  l->sz = n;

  return(l);
}

/*
##################
#Basic Operations#
##################
*/

/* Add one element into the set */
void set_insert(set* s, arrtype l)
{
  arr* k;
  int n;
  
  k = s->ua;
  n = s->sz;

  arr_set(k, n, l);
  s->sz = n+1;
}

/* Return size of the set */
int set_size(set* s)
{
  return(s->sz);
}

/* Returns true if l is in the array, false elsewise */
int set_contains(set* s, arrtype l)
{
  int i, n;

  n = s->sz;

  for(i = 0; i < n; i++)
  {
    if(s->ua->data[i] == l)
    {
      return(1);
    }
  }
  return(0);
}

int set_find_index(set* s, arrtype l)
{
  int i, n;

  n = s->sz;

  if(set_contains(s, l) == 0)
  {
    return(-1);
  }
  
  for(i = 0; i < n; i++)
  {
    if(s->ua->data[i] == l)
    {
      return(i);
    }
  }

  return(-1);
}

/* Remove l from the set (if it's in) */
void set_remove(set* s, arrtype l)
{
  int i, index_of_l, n;

  n = s->sz;

  if(set_contains(s, l) == 0)
  {
    return;
  }
  
  index_of_l = set_find_index(s, l);

  for(i = index_of_l; i < n-1; i++)
  {
    s->ua->data[i] = s->ua->data[i+1];
  }
  s->ua->data[n-1] = NOT_AN_ELEMENT;

  s->sz = n-1;
}

/* Remove one element from the set - there's no
   particular order for the elements, so any will do */
arrtype set_removeone(set* s)
{
  int i, n;

  n = s->sz;

  for(i = 0; i < n-1; i++)
  {
    s->ua->data[i] = s->ua->data[i+1];
  }
  s->ua->data[n-1] = NOT_AN_ELEMENT;

  s->sz = n-1;

  return(s->ua->data[0]);
}

/*
######################
#Operations on 2 sets#
######################
*/

/* Create a new set, containing all elements from s1 & s2 */
set* set_union(set* s1, set* s2)
{
  int i, n;
  set* new_set;
  new_set = set_init();
  new_set = set_copy(s1);

  n = s2->sz;
  
  for(i = 0; i < n; i++)
  {
    if(set_contains(s1, s2->ua->data[i]) == 0)
    {
      set_insert(new_set, s2->ua->data[i]);
    }
  }

  return(new_set);
}

/* Create a new set, containing all elements in both s1 & s2 */
set* set_intersection(set* s1, set* s2)
{
  int i, n;
  set* new_set;
  new_set = set_init();

  n = s2->sz;

  for(i = 0; i < n; i++)
  {
    if(set_contains(s1, s2->ua->data[i]) == 1)
    {
      set_insert(new_set, s2->ua->data[i]);
    }
  }

  return(new_set);
}

/*
###########
#Finish up#
###########
*/

/* Clears all space used, and sets pointer to NULL */
void set_free(set** s)
{
  return;
}
