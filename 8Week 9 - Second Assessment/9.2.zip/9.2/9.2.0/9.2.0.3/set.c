#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "set.h"

/* Create empty set */
set* set_init()
{
  set* l;

  l = calloc(1, sizeof(set));
  if(l == NULL)
  {
    ON_ERROR("Creation of set failed.\n");
  }

  l->ua = arr_init();
  l->sz = 0;

  return l;
}

/* Create new set, copied from another */
set* set_copy(set* s)
{
  set* l;
  int i, n;
  
  n = s->sz;

  l = calloc(1, sizeof(set));
  if(l == NULL)
  {
    ON_ERROR("Creation of set failed.\n");
  }

  l->ua = arr_init();
  for(i = 0; i < n; i++)
  {
    l->ua->data[i] = s->ua->data[i];
  }
  l->sz = n;
}

/* Create new set, copied from an array of length n */
set* set_fromarray(arrtype* a, int n)
{
  set* l;
  int i;

  l = calloc(1, sizeof(set));
  if(l == NULL)
  {
    ON_ERROR("Creation of set failed.\n");
  }

  l->ua = calloc(n, sizeof(arrtype));
  if(l->ua == NULL)
  {
    ON_ERROR("Creation of set failed.\n");
  }
  for(i = 0; i < n; i++)
  {
    l->ua->data[i] = a[i];
  }
  l->sz = n;
}

/*
##################
#Basic Operations#
##################
*/

/* Add one element into the set */
void set_insert(set* s, arrtype l)
{
  return;
}

/* Return size of the set */
int set_size(set* s)
{
  return(0);
}

/* Returns true if l is in the array, false elsewise */
int set_contains(set* s, arrtype l)
{
  return(0);
}

/* Remove l from the set (if it's in) */
void set_remove(set* s, arrtype l)
{
  return;
}

/* Remove one element from the set - there's no
   particular order for the elements, so any will do */
arrtype set_removeone(set* s)
{
  return(0);
}

/*
######################
#Operations on 2 sets#
######################
*/

/* Create a new set, containing all elements from s1 & s2 */
set* set_union(set* s1, set* s2)
{
  return(s1);
}

/* Create a new set, containing all elements in both s1 & s2 */
set* set_intersection(set* s1, set* s2)
{
  return(s1);
}

/*
###########
#Finish up#
###########
*/

/* Clears all space used, and sets pointer to NULL */
void set_free(set** s)
{
  return;
}
