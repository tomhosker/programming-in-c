#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "set.h"

/* Create empty set */
set* set_init()
{
  return(NULL);
}

/* Create new set, copied from another */
set* set_copy(set* s)
{
  return(s);
}

/* Create new set, copied from an array of length n*/
set* set_fromarray(arrtype* a, int n)
{
  return(NULL);
}

/*
##################
#Basic Operations#
##################
*/

/* Add one element into the set */
void set_insert(set* s, arrtype l)
{
  return;
}

/* Return size of the set */
int set_size(set* s)
{
  return(0);
}

/* Returns true if l is in the array, false elsewise */
int set_contains(set* s, arrtype l)
{
  return(0);
}

/* Remove l from the set (if it's in) */
void set_remove(set* s, arrtype l)
{
  return;
}

/* Remove one element from the set - there's no
   particular order for the elements, so any will do */
arrtype set_removeone(set* s)
{
  return(0);
}

/*
######################
#Operations on 2 sets#
######################
*/

/* Create a new set, containing all elements from s1 & s2 */
set* set_union(set* s1, set* s2)
{
  return(s1);
}

/* Create a new set, containing all elements in both s1 & s2 */
set* set_intersection(set* s1, set* s2)
{
  return(s1);
}

/*
###########
#Finish up#
###########
*/

/* Clears all space used, and sets pointer to NULL */
void set_free(set** s)
{
  return;
}
