/*##########################################################
############################################################
###################### A Program in C ######################
###################### to Demonstrate ######################
################### the Creation and Use ###################
##################### of Logical Sets ######################
########################## v 1.4 ###########################
############################################################
###################### by TOM HOSKER #######################
############################################################
####################### 22 Nov 2017 ########################
############################################################
############# nisi Dominus aedificaverit domum #############
############################################################
############################################################
############### Znl gur fbhy bs Qnivq Pbbx, ################
################### Puvrs Bssvpre Eblny ####################
################# Syrrg Nhkvyvnel Freivpr, #################
##################### jevgur va ntbal ######################
################## orgjrra Fngna'f grrgu. ##################
############################################################
##########################################################*/

/*###########
### NOTES ###
#############

This file requires the presence of others,
notably set.c, in order to compile properly.

There are 6257 unique words in pride-and-prej.txt
There are 6268 unique words in sense-and-sense.txt
There are 4237 common words */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "set.h"

#define MAX_LET 50
#define FIRST_BOOK "pride-and-prej.txt"
#define SECOND_BOOK "sense-and-sense.txt"

void generate_set(set* set, char *filename);

int main(void)
{
  set* set_1;
  set* set_2;
  set* set_3;

  set_1 = set_init();
  set_2 = set_init();
  set_3 = set_init();

  generate_set(set_1, FIRST_BOOK);
  generate_set(set_2, SECOND_BOOK);
  set_3 = set_intersection(set_1, set_2);

  printf("There are %i unique words in %s\n",
    set_size(set_1), FIRST_BOOK);
  printf("There are %i unique words in %s\n",
    set_size(set_2), SECOND_BOOK);
  printf("There are %i common words\n", set_size(set_3));
  return(0);
}

void generate_set(set* set, char *filename)
{
  static char line[MAX_LET];
  arrtype token;
  void *p;
  int i = 0;
  FILE *file = fopen(filename, "r");
  p = &token;

  if(file != NULL)
  {
    while(fgets(line, MAX_LET, file) != NULL)
    {
      memset(p, 0, sizeof(arrtype));
      strcpy(token.str, strtok(line, "\n"));
      set_insert(set, token);
      i++;
    }
  }
  else
  {
    printf("Failed to open file.");
    return;
  }
  fclose(file);
}
