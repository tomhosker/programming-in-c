#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "set.h"

#define MAX_LET 50
#define FIRST_BOOK "first_poem.txt"
#define SECOND_BOOK "second_poem.txt"

void generate_set(set* set, char *filename);

void print_set(set* set, int n);

int main(void)
{
  set* set_1;
  set* set_2;
  set* set_3;
  int a, b, c;

  set_1 = set_init();
  set_2 = set_init();
  set_3 = set_init();

  generate_set(set_1, FIRST_BOOK);
  generate_set(set_2, SECOND_BOOK);
  set_3 = set_intersection(set_1, set_2);

  a = set_size(set_1);
  b = set_size(set_2);
  c = set_size(set_3);
  
  print_set(set_1, 12);
  printf("\n");
  printf("%i, %i, %i\n", a, b, c);
  return(0);
}

void generate_set(set* set, char *filename)
{
  static char line[MAX_LET];
  arrtype token;
  int i = 0;
  FILE *file = fopen(filename, "r");

  if(file != NULL)
  {
    while(fgets(line, MAX_LET, file) != NULL)
    {
      strcpy(token.str, strtok(line, "\n"));
      set_insert(set, token);
      i++;
    }
  }
  else
  {
    printf("Failed to open file.");
    return;
  }
  fclose(file);
}

void print_set(set* set, int n)
{
  int i;

  for(i = 0; i < n; i++)
  {
    printf("%s ", set->ua->data[i].str);
  }
}
